//
//  Sound.m
//  testFunctionMp3
//
//  Created by admin on 2020/12/22.
//

#import "GJSound.h"

@interface GJSound()<AVAudioPlayerDelegate>

@end

@implementation GJSound


+(instancetype)sharedInstance{
    static GJSound *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
        [instance configMp3];
    });
    return instance;
    
    
//    AVAudioSession *se
}

-(void)configMp3
{
    _audioSession = [AVAudioSession sharedInstance];
    [_audioSession setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionMixWithOthers error:nil];
    [_audioSession setActive:YES error:nil];
//    [_audioSession setActive:YES withOptions:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation error:nil]; //当前应用解除激活状态后，恢复其他应用的session
    
}

-(void)playWithName:(NSString *)filePath{
//    NSString *filePath = [NSString stringWithFormat:@"%@/%@",@"AWSDK.bundle",name];
    NSURL* url = [NSURL fileURLWithPath:filePath];
    if(!staticAudioPlayer){
        staticAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        [staticAudioPlayer prepareToPlay];
        staticAudioPlayer.delegate = self;
        
    }
    staticAudioPlayer.volume = 10;
    staticAudioPlayer.currentTime = 0;
    if (!staticAudioPlayer.isPlaying) {
        [staticAudioPlayer play];
    }
}

-(void)stop{
    staticAudioPlayer.currentTime = 0;
    [staticAudioPlayer stop];
}

-(void)pause
{
    [staticAudioPlayer pause];
    NSLog(@"currentTime==%lf",staticAudioPlayer.currentTime);
}

-(void)play
{
    if (!staticAudioPlayer.isPlaying) {
        [staticAudioPlayer play];
    }
}

-(void)playAtTime:(NSTimeInterval)time andfilePath:(NSString *)filePath
{
    staticAudioPlayer.currentTime = time;
    if (staticAudioPlayer) {
        
        [staticAudioPlayer play];
    }else{
//        [self playWithName:filePath];
        NSURL* url = [NSURL fileURLWithPath:filePath];
        if(!staticAudioPlayer){
            staticAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
            [staticAudioPlayer prepareToPlay];
            staticAudioPlayer.delegate = self;
        }
        staticAudioPlayer.volume = 10;
        staticAudioPlayer.currentTime = time;
        if (!staticAudioPlayer.isPlaying) {
            [staticAudioPlayer play];
        }
    }

//    [self playWithName:filePath];
//    [self playWithName:filePath];
//    staticAudioPlayer
//    [staticAudioPlayer playAtTime:time];
//    [staticAudioPlayer play];
//    [self playWithName:filePath];
//    NSURL* url = [NSURL fileURLWithPath:filePath];
//    if(!staticAudioPlayer){
//        staticAudioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
//        [staticAudioPlayer prepareToPlay];
//        staticAudioPlayer.delegate = self;
//    }
//    staticAudioPlayer.volume = 10;
//    staticAudioPlayer.currentTime = 50;
//    if (!staticAudioPlayer.isPlaying) {
////        staticAudioPlayer.currentTime = 50;
//        [staticAudioPlayer play];
////        [staticAudioPlayer playAtTime:time];
//    }

}

#pragma MARK -- 一首播放完了
- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    NSLog(@"delegatexxx");
//    staticAudioPlayer = nil;
//    这里判断 下一首 还是循环播放， 获取下一首
}

//音频编码错误
- (void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError * __nullable)error
{
    //给个提示 然后下一首吧
}

//中断 和 锁屏  其他音频启动的配置 用AVAudioSession的通知

@end
