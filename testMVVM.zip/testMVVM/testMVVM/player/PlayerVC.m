//
//  PlayerVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/6.
//

#import "PlayerVC.h"

#import <MediaPlayer/MediaPlayer.h>
#import "GJSound.h"

@interface PlayerVC ()
@property (nonatomic, strong) AVPlayer * player;
@end

@implementation PlayerVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
}

-(void)createUI
{
    
    NSArray *btnArr = @[@"获取时长",@"播放",@"暂停",@"下一首",@"快进",@"指定时间播放"];
    int count = (int) btnArr.count;
    for (int i=0; i<count; i++) {
        UIButton *playerBtn = [[UIButton alloc]initWithFrame:CGRectMake(100, 100+50 * i, 150, 40)];
        [self.view addSubview:playerBtn];
        [playerBtn setTitle:btnArr[i] forState:UIControlStateNormal];
        playerBtn.backgroundColor = [UIColor redColor];
        playerBtn.tag = 100+i;
        [playerBtn addTarget:self action:@selector(clickPlayer:) forControlEvents:UIControlEventTouchUpInside];
    }
    
}

-(void)clickPlayer:(UIButton *)sender
{
    switch (sender.tag) {
        case 100:
            [self getAllTime];
            break;
        case 101:
            [self play];
            break;
        case 102:
            [self pause];
            break;
        case 103:
            [self nextmp3];
            break;
        case 104:
            [self quick];
            break;
        case 105:
            [self playAtTime];
            break;
        case 106:
            //
            break;
            
        default:
            break;
    }

}
//@[@"获取时长",@"播放",@"暂停",@"下一首",@"快进",@"指定时间播放"];
-(void)getAllTime
{
    NSLog(@"%s",__func__);
    NSString * path = [[NSBundle mainBundle] pathForResource:@"多幸运" ofType:@"mp3"];
    NSData *data = [NSData dataWithContentsOfURL:[NSURL fileURLWithPath:path]];
    AVAudioPlayer* player = [[AVAudioPlayer alloc] initWithData:data error:nil];

//    double duration = player.duration;

    NSLog(@"音频时长:%lf",player.duration);

}

-(void)play
{
    NSLog(@"%s",__func__);
    NSString * path = [[NSBundle mainBundle] pathForResource:@"多幸运" ofType:@"mp3"];
//    [[GJSound sharedInstance] playWithName:path];
    [[GJSound sharedInstance] play];
}

-(void)pause
{
    NSLog(@"%s",__func__);
    [[GJSound sharedInstance] pause];
}

-(void)nextmp3
{
    NSLog(@"%s",__func__);
}

-(void)quick
{
    NSLog(@"%s",__func__);
}

-(void)playAtTime
{
    NSLog(@"%s",__func__);
    NSTimeInterval timei = 50;
    NSString * path = [[NSBundle mainBundle] pathForResource:@"多幸运" ofType:@"mp3"];
    
    
    [[GJSound sharedInstance] playAtTime:timei andfilePath:path];
}

//- (AVPlayer *)player{
//
//    if (_player == nil) {
//        NSString * path = [[NSBundle mainBundle] pathForResource:@"多幸运" ofType:@"mp3"];
//        _player = [[AVPlayer alloc] initWithURL:[NSURL fileURLWithPath:path]];
//    }
//    return _player;
//}

@end
