//
//  Sound.h
//  testFunctionMp3
//
//  Created by admin on 2020/12/22.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
NS_ASSUME_NONNULL_BEGIN
static AVAudioPlayer* staticAudioPlayer;
@interface GJSound : NSObject
{
    AVAudioSession* _audioSession;
}

+(instancetype)sharedInstance;

//停止
-(void)stop;

//暂停
-(void)pause;
//播放
-(void)play;

//指定时间播放 可以重复播放
-(void)playAtTime:(NSTimeInterval)time andfilePath:(NSString *)filePath;

@end

NS_ASSUME_NONNULL_END
