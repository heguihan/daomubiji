//
//  AppDelegate.h
//  testMVVM
//
//  Created by 感觉 on 2022/4/28.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

