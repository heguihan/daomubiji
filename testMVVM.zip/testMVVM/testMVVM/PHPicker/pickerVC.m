//
//  pickerVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/7.
//

#import "pickerVC.h"

#import <Photos/Photos.h>
#import <PhotosUI/PhotosUI.h>

#import "YQImageCompressTool.h"

@import MobileCoreServices;

@interface pickerVC ()<PHPickerViewControllerDelegate>
@property (nonatomic, strong) UIImageView *imageV;
@property (nonatomic, strong) UIImage *Showimage;

@end

@implementation pickerVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
//    [self testData];
}

-(void)testData
{
    NSString *udfLanguageCode = [[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"][0];
//    NSLog(NSString * _Nonnull format, ...)
    NSArray *arr = [[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"];
    NSLog(@"arr = %@",arr);
    
    NSString *language = [[NSLocale preferredLanguages] objectAtIndex:0];
    /*
     @property (class, readonly, copy) NSArray<NSString *> *availableLocaleIdentifiers;
     @property (class, readonly, copy) NSArray<NSString *> *ISOLanguageCodes;
     @property (class, readonly, copy) NSArray<NSString *> *ISOCountryCodes;
     @property (class, readonly, copy) NSArray<NSString *> *ISOCurrencyCodes;
     @property (class, readonly, copy) NSArray<NSString *> *commonISOCurrencyCodes
     */
    NSArray *arr1 = [NSLocale availableLocaleIdentifiers];
    NSArray *arr2 = [NSLocale ISOLanguageCodes];
    NSArray *arr3 = [NSLocale ISOCountryCodes];
    NSArray *arr4 = [NSLocale ISOCurrencyCodes];
    NSArray *arr5 = [NSLocale commonISOCurrencyCodes];
    NSLog(@"arr1=%@,arr2=%@,arr3=%@,arr4=%@,arr5=%@",arr1,arr2,arr3,arr4,arr5);
    NSLog(@"the end");
}

-(void)createUI
{
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 40)];
    [btn addTarget:self action:@selector(clickPicker) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    btn.backgroundColor = [UIColor orangeColor];
    [btn setTitle:@"选择" forState:UIControlStateNormal];
    
    self.imageV = [[UIImageView alloc]initWithFrame:CGRectMake(100, 250, 200, 400)];
//    self.imageV.layer.cornerRadius = 50;
//    self.imageV.layer.masksToBounds = YES;
    [self.view addSubview:self.imageV];
    self.imageV.backgroundColor = [UIColor redColor];
    
    NSString * imgpath= [ [ NSBundle mainBundle] pathForResource:@"test" ofType:@"png"];

    UIImage *image=[UIImage imageWithContentsOfFile: imgpath];
    
    self.Showimage = image;
    
    self.imageV.image = self.Showimage;
}

-(void)clickPicker
{
    
    
//    UIImage *image  = [UIImage imageNamed:@"test.png"];
    
//    NSString * imgpath= [ [ NSBundle mainBundle] pathForResource:@"test" ofType:@"png"];

    UIImage *image=self.Showimage;
    
    
    NSInteger sizelength = [self getImageSize:image];
    NSLog(@"before==%ld",sizelength);
    
    
    NSData *data = UIImageJPEGRepresentation(image, 0.8);
    UIImage *newImage = [UIImage imageWithData:data];
    NSInteger yaLength = [data length];
    NSLog(@"ya ==%ld",[data length]);
//    self.imageV.image = newImage;
    
    
////    UIImage *suoImage = [self imageByScalingAndCroppingForSize:CGSizeMake(50, 100) withSourceImage:image];
//    for (int i=0; i<6; i++) {
//        float s = (i+5)/10.0;
//        UIImage *suoImagefor = [self imageByScale:s image:image];
//
//        NSInteger suosizelengthfor = [self getImageSize:suoImagefor];
//        NSLog(@"ss==%f",s);
//        NSLog(@"suofor scale==%lf",sizelength/(suosizelengthfor * 1.0));
//
//    }
    
//    UIImage *suoImage = [self imageByScale:0.8 image:image];
    UIImage *suoImage = [YQImageCompressTool OnlyCompressToImageWithImage:image FileSize:103014];
    suoImage = [YQImageCompressTool OnlyCompressToImageWithImage:suoImage FileSize:103014];
    NSData *dataxxx = UIImageJPEGRepresentation(suoImage, 1.0);
    NSInteger suosizelength = [self getImageSize:suoImage];
    NSLog(@"suo==%ld",suosizelength);
    NSLog(@"xxx");
    self.imageV.image = suoImage;
//    self.imageV.contentMode = UIViewContentModeScaleAspectFit ;
    
    NSLog(@"suo scale==%lf",sizelength/(suosizelength * 1.0));
    NSLog(@"ya scale==%lf",sizelength/(yaLength * 1.0));
    
    return;
    
    NSLog(@"picker");
    
//    PHPickerFilter *filter = [PHPickerFilter anyFilterMatchingSubfilters:@[PHPickerFilter.videosFilter]];//过滤器提供三种类型的过滤imagesFilter、videosFilter和livePhotosFilter

    PHPickerConfiguration *config = [[PHPickerConfiguration alloc] init];
    config.selectionLimit = 1;
    config.filter = [PHPickerFilter imagesFilter];
    
    PHPickerViewController *pickerViewController = [[PHPickerViewController alloc] initWithConfiguration:config];
    pickerViewController.delegate = self;
    [self presentViewController:pickerViewController animated:YES completion:nil];
}

-(void)picker:(PHPickerViewController *)picker didFinishPicking:(NSArray<PHPickerResult *> *)results{
    NSLog(@"did selected");
//    [self clearImageViews];
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    for (PHPickerResult *result in results) {
        NSLog(@"result: %@", result);
        
        NSLog(@"id %@", result.assetIdentifier);
        NSLog(@"item %@", result.itemProvider);
        
        // Get UIImage
        [result.itemProvider loadObjectOfClass:[UIImage class] completionHandler:^(__kindof id<NSItemProviderReading>  _Nullable object, NSError * _Nullable error) {
            NSLog(@"object: %@, error: %@", object, error);

            if ([object isKindOfClass:[UIImage class]]) {
                dispatch_async(dispatch_get_main_queue(), ^{
//                    UIImageView *imageView = [self newImageViewForImage:(UIImage*)object];
                    self.imageV.image = (UIImage *)object;
                    NSInteger imageSize = [self getImageSize:(UIImage *)object];
                    NSLog(@"imageSize==%ld",imageSize);
                    [self.view setNeedsLayout];
                });
            }
        }];
        

    }
    
}



-(NSInteger)getImageSize:(UIImage *)thumbImage
{
    NSData *data = UIImageJPEGRepresentation(thumbImage, 1.0);
//    if (!data) {
//        data = UIImageJPEGRepresentation(thumbImage, 1.0);//需要改成0.5才接近原图片大小，原因请看下文 //521233
//    }
    NSInteger dataLength = [data length] ;
    NSLog(@"dataLengthxx==%ld",dataLength);
    return dataLength;
    
//    NSData * imageData = UIImageJPEGRepresentation(thumbImage,1);
//    NSInteger length = [imageData length]/1000;
//    NSLog(@"length==%ld",length);
//
//    NSString *len = [self getBytesFromDataLength:imageData.length];
//    NSLog(@"len==%@",len);
//
//    NSUInteger s0 = CGImageGetWidth(thumbImage.CGImage);
//    NSUInteger s1  = CGImageGetHeight(thumbImage.CGImage);
//    NSUInteger s2  = CGImageGetBytesPerRow(thumbImage.CGImage);
//    NSUInteger s3  = CGImageGetHeight(thumbImage.CGImage) * CGImageGetBytesPerRow(thumbImage.CGImage);
//    NSUInteger s4 = CGImageGetBitsPerComponent(thumbImage.CGImage);
//    NSLog(@"s0=%ld, s1=%ld, s2=%ld, s3=%ld, s4=%ld",s0,s1,s2,s3,s4);
//    return s3;
}


- (NSString *)getBytesFromDataLength:(NSInteger)dataLength {
    NSString *bytes;
    if (dataLength >= 0.1 * (1024 * 1024)) {
        bytes = [NSString stringWithFormat:@"%0.1fM",dataLength/1024/1024.0];
    } else if (dataLength >= 1024) {
        bytes = [NSString stringWithFormat:@"%0.0fK",dataLength/1024.0];
    } else {
        bytes = [NSString stringWithFormat:@"%zdB",dataLength];
    }
    return bytes;
}


- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize withSourceImage:(UIImage *)sourceImage
{
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        if (widthFactor > heightFactor)
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth= width * scaleFactor;
        scaledHeight = height * scaleFactor;
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else if (widthFactor < heightFactor)
        {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    
    UIGraphicsBeginImageContext(targetSize); // this will crop
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width= scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextClipToRect(context, thumbnailRect);
    
    [sourceImage drawInRect:thumbnailRect];
    newImage = UIGraphicsGetImageFromCurrentImageContext();

    if(newImage == nil)
        NSLog(@"could not scale image");

    //pop the context to get back to the default
    UIGraphicsEndImageContext();

    return newImage;
}


-(UIImage *)imageByScale:(CGFloat)scale image:(UIImage *)sourceImage
{
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    
    CGSize targetSize = CGSizeMake(width*scale, height*scale);
//
//    CGFloat pointX = 0-(width -width*scale)/2.0;
//    CGFloat pointY = 0-(height - height*scale)/2.0;
//
//    thumbnailPoint = CGPointMake(pointX, pointY);
    
    UIGraphicsBeginImageContext(targetSize); // this will crop
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width= width * scale;
    thumbnailRect.size.height = height * scale;
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextClipToRect(context, thumbnailRect);
    [sourceImage drawInRect:thumbnailRect];
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil)
        NSLog(@"could not scale image");
    
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    
    return newImage;
}

@end
