//
//  BaseVC.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/11.
//

#import <UIKit/UIKit.h>
#import <TABAnimated.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseVC : UIViewController
@property (nonatomic, strong) UITableView *tableview;
@property (nonatomic, strong) UICollectionView *collectView;
-(void)setTabAnimated:(NSArray *)classArr heightArr:(NSArray *)heightArr countArr:(NSArray *)countArr;
-(void)setCollectTabAnimated:(NSArray *)classArr sizeArr:(NSArray *)sizeArr countArr:(NSArray *)countArr;
-(void)reloadTableView;
-(void)reloadCollectView;
@end

NS_ASSUME_NONNULL_END
