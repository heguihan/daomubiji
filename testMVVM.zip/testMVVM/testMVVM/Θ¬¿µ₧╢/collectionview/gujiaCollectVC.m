//
//  gujiaCollectVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/11.
//

#define FIT(value)          value

#import "gujiaCollectVC.h"
#import "oneCell.h"
#import "twoCell.h"


@interface gujiaCollectVC ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property (nonatomic, strong) NSMutableArray *dataArr;
@end

@implementation gujiaCollectVC
@synthesize collectView = _collectView;


- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
    [self registerCell];
//    [self getData];
    [self performSelector:@selector(afterGetData) withObject:nil afterDelay:3.0];
}

-(void)afterGetData
{
    [self getData];
}

-(void)getData
{
    NSMutableArray *mutabarr1 = [NSMutableArray array];
    for (int i = 0; i<9; i++) {
        [mutabarr1 addObject:[NSNumber numberWithInt:i]];
    }
    
    NSMutableArray *mutabarr2 = [NSMutableArray array];
    for (int i = 0; i<10; i++) {
        [mutabarr2 addObject:[NSNumber numberWithInt:i]];
    }
    [self.dataArr addObject:[mutabarr1 copy]];
    [self.dataArr addObject:[mutabarr2 copy]];
//    [self.collectView reloadData];
    [self reloadCollectView];
}

-(void)createUI
{
    [self.view addSubview:self.collectView];
    
    NSArray *classArr = @[[oneCell class],[twoCell class]];
    CGSize size1 = CGSizeMake(100, 150);
    CGSize size2 = CGSizeMake(350, 130);
    NSArray *sizeArr = @[[NSValue valueWithCGSize:size1],[NSValue valueWithCGSize:size2]];
    NSArray *countArr = @[@9,@19];
    
 /*
    NSArray *classArray = @[
                            [twoCell class],
                            [oneCell class],
                            ];
    NSArray *sizeArray = @[
                           [NSValue valueWithCGSize:size1],
                           [NSValue valueWithCGSize:size2],
                           ];
    
    self.collectView.tabAnimated = [TABCollectionAnimated
                                   animatedWithCellClassArray:classArr
                                   cellSizeArray:sizeArr
                                   animatedCountArray:countArr];
    [self.collectView tab_startAnimation];
    
*/
    [self setCollectTabAnimated:classArr sizeArr:sizeArr countArr:countArr];
    
}

-(void)registerCell
{
    [self.collectView registerClass:[oneCell class] forCellWithReuseIdentifier:@"one"];
    [self.collectView registerClass:[twoCell class] forCellWithReuseIdentifier:@"two"];
}

#pragma mark -- layout delegate
//items的间距

static CGFloat _item_left = 25;
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    UIEdgeInsets edg = UIEdgeInsetsMake(FIT(12), FIT(20), FIT(12), FIT(20));//top, left, bottom, right items直接的间距
    if (section == 1) {
        edg = UIEdgeInsetsMake(FIT(16), FIT(16+20), FIT(16), FIT(16+20));
    }
    return edg;
}
//items的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
//    NSLog(@"fit 167==%f, screenWidth==%f",FIT(167),SCREENWIDTH);
    CGSize threeSize = CGSizeMake(FIT(98), FIT(150));
    if (indexPath.section == 2) {
        threeSize = CGSizeMake(FIT(167), FIT(160));
    }else if (indexPath.section == 1){
        threeSize = CGSizeMake(FIT(350), FIT(130));
    }
    return threeSize;
}

#pragma mark -- dataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{

    if (self.dataArr.count<1) {
        return 0;
    }
    NSArray *arr = self.dataArr[section];
    return arr.count;

}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{

   return self.dataArr.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
//    GJThreeCollectionViewCell *cell
    if (indexPath.section == 1) {
        oneCell *cell = [oneCell alloc];
        cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"one" forIndexPath:indexPath];
        [cell setData];
        return cell;
    }
    
    twoCell *cell = [twoCell alloc];
    cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"two" forIndexPath:indexPath];
    [cell setData];
    return cell;


}
//header section
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *reusableView = nil;
    if (kind == UICollectionElementKindSectionHeader) {
        UICollectionReusableView *header = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headview" forIndexPath:indexPath];
        
        reusableView = header;
    }

    return reusableView;
}


#pragma MARK -- getter
-(NSMutableArray *)dataArr
{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}
/*
 _collectLayout = [[JJCollectionViewRoundFlowLayout alloc] init];
 [_collectLayout setScrollDirection:UICollectionViewScrollDirectionVertical];
 _collectLayout.itemSize = CGSizeMake(CELLWIDTH3, CELLWIDTH3+FIT(40));

 _collectLayout.minimumLineSpacing = 10;

 _collectLayout.minimumInteritemSpacing = 10;

 // 设置组头大小
 _collectLayout.headerReferenceSize = CGSizeMake(SCREENWIDTH, 30);
 */
-(UICollectionView *)collectView
{
    if (!_collectView) {
        UICollectionViewFlowLayout *layOut = [[UICollectionViewFlowLayout alloc]init];
        [layOut setScrollDirection:UICollectionViewScrollDirectionVertical];
        
        
        
        
        _collectView = [[UICollectionView alloc]initWithFrame:self.view.bounds collectionViewLayout:layOut];
        _collectView.delegate = self;
        _collectView.dataSource = self;
//        _collectView.backgroundColor = TESTCOLOR;
        
    }
    return _collectView;
}

@end
