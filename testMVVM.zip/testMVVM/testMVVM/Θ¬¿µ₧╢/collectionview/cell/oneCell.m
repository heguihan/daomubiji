//
//  oneCell.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/11.
//

#import "oneCell.h"
#import <Masonry/Masonry.h>

@interface oneCell()
@property (nonatomic, strong) UIImageView *imageV;
@property (nonatomic, strong) UILabel *lab1;
@end

@implementation oneCell

-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self configUIWithFrame:frame];
    }
    return self;
}

-(void)configUIWithFrame:(CGRect)frame
{
    CGFloat mainWidth = frame.size.width;
    CGFloat mainHeight = frame.size.height;
    
    [self.contentView addSubview:self.imageV];
    [self.contentView addSubview:self.lab1];
    self.contentView.backgroundColor = [UIColor redColor];
    
    [self.imageV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.offset(0);
            make.left.offset(20);
            make.size.mas_equalTo(CGSizeMake(100, 100));
    }];
    [self.lab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.imageV.mas_right).offset(20);
            make.centerY.offset(0);
            make.height.mas_equalTo(20);
            make.width.mas_equalTo(200);
    }];
    
}

-(void)setData
{
    self.imageV.image = [UIImage imageNamed:@"comic.jpg"];
    self.lab1.text = @"aaaaaaaaa";
}

#pragma mark -- getter
-(UIImageView *)imageV
{
    if (!_imageV) {
        _imageV = [[UIImageView alloc]init];
    }
    return _imageV;
}

-(UILabel *)lab1
{
    if (!_lab1) {
        _lab1 = [[UILabel alloc]init];
    }
    return _lab1;
}

@end
