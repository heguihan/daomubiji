//
//  BaseVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/11.
//

#import "BaseVC.h"

@interface BaseVC ()
@property(nonatomic, assign)BOOL isNeedTabAnimation;
@end

@implementation BaseVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configUI];
    [self initConfig];
}

-(void)initConfig
{
    self.isNeedTabAnimation = NO;
}

-(void)configUI
{
    [self.view addSubview:self.tableview];
    [self.view addSubview:self.collectView];
}

-(void)setTabAnimated:(NSArray *)classArr heightArr:(NSArray *)heightArr countArr:(NSArray *)countArr
{
    self.isNeedTabAnimation = YES;
    self.tableview.tabAnimated =[TABTableAnimated animatedWithCellClassArray:classArr
                                 cellHeightArray:heightArr
                              animatedCountArray:countArr];
//    [_tableview.tabAnimated addHeaderViewClass:[UIView class] viewHeight:60 toSection:0];
//    [_tableview.tabAnimated addHeaderViewClass:[UIView class] viewHeight:60 toSection:1];
    _tableview.tabAnimated.adjustWithClassBlock = ^(TABComponentManager *manager, __unsafe_unretained Class targetClass) {
        manager.animation(3).width(100);
//        if (targetClass == gujiaCell.class) {
//           manager.animation(1).down(3).height(12);
//           manager.animation(2).height(12).width(110);
//           manager.animation(3).down(-5).height(12);
//        }else if (targetClass == UIView.class) {
//            manager.animation(2).right(3).height(14).down(16).reducedWidth(30).radius(2);
//        }else if (targetClass == twoSecCell.class) {
//            manager.animations(1, 3).height(12);
//            manager.animation(2).down(8).reducedWidth(-90);
//        }
    };
    
    
    [self.tableview tab_startAnimationWithCompletion:^{
          
    }];
}

-(void)setCollectTabAnimated:(NSArray *)classArr sizeArr:(NSArray *)sizeArr countArr:(NSArray *)countArr
{
    
    self.collectView.tabAnimated = [TABCollectionAnimated
                                   animatedWithCellClassArray:classArr
                                   cellSizeArray:sizeArr
                                   animatedCountArray:countArr];
//    self.collectView.tabAnimated.containNestAnimation = YES;
//    self.collectView.tabAnimated.canLoadAgain = YES;
    if (@available(iOS 13.0, *)) {
        self.collectView.tabAnimated.darkAnimatedBackgroundColor = UIColor.systemBackgroundColor;
    }
    self.collectView.tabAnimated.adjustWithClassBlock = ^(TABComponentManager * _Nonnull manager, Class  _Nonnull __unsafe_unretained targetClass) {
        manager.animation(1).height(12).down(-2).reducedWidth(-90);
//        manager.animation(2).height(12).down(7).reducedWidth(-30);
//        manager.animation(3).height(12).down(-2).reducedWidth(150);
//        manager.animations(5,3).down(4).right(30);
    };
    
    
    [self.collectView tab_startAnimation];
}

-(void)reloadTableView
{
    [self.tableview reloadData];
    if (self.isNeedTabAnimation) {
        [self.tableview tab_endAnimationEaseOut];
    }
    
}
-(void)reloadCollectView
{
    [self.collectView reloadData];
//    [self.collectView tab_endAnimationWithIndex:1];
//    tab_endAnimationEaseOut
    [self.collectView tab_endAnimationEaseOut];
}

@end
