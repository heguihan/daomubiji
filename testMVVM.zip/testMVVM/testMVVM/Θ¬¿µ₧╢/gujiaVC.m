//
//  gujiaVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/11.
//

#import "gujiaVC.h"
//#import "TestCell.h"
#import "gujiaCell.h"
#import "twoSecCell.h"

static const NSTimeInterval TABAnimatedDemoDelayTime = 3.;


@interface gujiaVC ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) NSMutableArray *dataArr;

@end

@implementation gujiaVC
@synthesize tableview = _tableview;


- (void)viewDidLoad {
    [super viewDidLoad];
    [self registerCell];
    [self createUI];
    [self initData];

}

-(void)afterGetData
{
    NSLog(@"afterdata");
    NSMutableArray *mutabarr1 = [NSMutableArray array];
    for (int i = 0; i<2; i++) {
        [mutabarr1 addObject:[NSNumber numberWithInt:i]];
    }
    
    NSMutableArray *mutabarr2 = [NSMutableArray array];
    for (int i = 0; i<10; i++) {
        [mutabarr2 addObject:[NSNumber numberWithInt:i]];
    }
    [self.dataArr addObject:[mutabarr1 copy]];
    [self.dataArr addObject:[mutabarr2 copy]];
//    [self.tableview tab_endAnimationEaseOut];
//    [self.tableview reloadData];
    [self reloadTableView];
}

-(void)registerCell
{
    [self.tableview registerClass:[gujiaCell class] forCellReuseIdentifier:@"cell"];
    [self.tableview registerClass:[twoSecCell class] forCellReuseIdentifier:@"cell2"];
}

-(void)createUI
{
    [self.view addSubview:self.tableview];
    
    
    NSArray *classArr = @[[twoSecCell class]];
    NSArray *heightArr = @[@180];
    NSArray *countArr = @[@33];
    
    [self setTabAnimated:classArr heightArr:heightArr countArr:countArr];
      


}

-(void)setupData
{
    // 假设3秒后，获取到数据了，代码具体位置看你项目了。
    [self performSelector:@selector(afterGetData) withObject:nil afterDelay:TABAnimatedDemoDelayTime];
}

-(void)initData
{
    [self setupData];
}

#pragma delegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 140;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    NSArray *arr = [self.dataArr mutableCopy];
    return arr.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.dataArr.count<1) {
        return 0;
    }
    NSArray *arr = self.dataArr[section];
    return arr.count;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section>=1) {
        twoSecCell *cell2 = [[twoSecCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell2"];
        [cell2 setData];
        return cell2;
    }
    
    gujiaCell *cell = [[gujiaCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    [cell setData];
    return cell;
}

#pragma MARK -- getter

-(UITableView *)tableview
{
    if (!_tableview) {
        _tableview = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
        _tableview.backgroundColor = [UIColor yellowColor];
        _tableview.delegate = self;
        _tableview.dataSource = self;
    }
    return _tableview;
}

-(NSMutableArray *)dataArr
{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}

@end
