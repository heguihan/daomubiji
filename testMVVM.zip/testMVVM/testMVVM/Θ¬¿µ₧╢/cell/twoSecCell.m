//
//  twoSecCell.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/11.
//

#import "twoSecCell.h"
#import <Masonry/Masonry.h>

@interface twoSecCell()
@property (nonatomic, strong) UIImageView *imageV;
@property (nonatomic, strong) UILabel *lab1;
@property (nonatomic, strong) UILabel *lab2;
@property (nonatomic, strong) UILabel *lab3;
@property (nonatomic, strong) UIButton *btn;
@property (nonatomic, strong) UIView *view1;

@end

@implementation twoSecCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self configUI];
    }
    return self;
}

-(void)configUI
{
    [self.contentView addSubview:self.imageV];
    [self.contentView addSubview:self.lab1];
    [self.contentView addSubview:self.lab2];
    [self.contentView addSubview:self.lab3];
    [self.contentView addSubview:self.btn];
    [self.contentView addSubview:self.view1];
    
    [self.imageV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.offset(0);
            make.left.offset(150);
            make.size.mas_equalTo(CGSizeMake(100, 100));
    }];
    [self.lab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.offset(15);
            make.top.offset(20);
            make.height.mas_equalTo(20);
            make.width.mas_equalTo(180);
    }];
    [self.lab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.offset(15);
            make.top.mas_equalTo(self.lab1.mas_bottom).offset(10);
            make.height.mas_equalTo(20);
            make.width.mas_equalTo(180);
    }];
    [self.lab3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.offset(15);
            make.top.mas_equalTo(self.lab2.mas_bottom).offset(10);
            make.height.mas_equalTo(20);
            make.width.mas_equalTo(180);
    }];
    
    [self.btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.offset(-20);
        make.centerY.offset(0);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    
}

-(void)setData
{
    self.imageV.image = [UIImage imageNamed:@"head.jpg"];
    self.lab1.text = @"qqqq";
    self.lab2.text = @"wwwwwwwww";
    self.lab3.text = @"xxxx";
    [self.btn setImage:[UIImage imageNamed:@"icon_add"] forState:UIControlStateNormal];
    
}

#pragma MARK -- getter
-(UIImageView *)imageV
{
    if (!_imageV) {
        _imageV = [[UIImageView alloc]init];
    }
    return _imageV;
}

-(UILabel *)lab1
{
    if (!_lab1) {
        _lab1 = [[UILabel alloc]init];
    }
    return _lab1;
}

-(UILabel *)lab2
{
    if (!_lab2) {
        _lab2 = [[UILabel alloc]init];
    }
    return _lab2;
}
-(UILabel *)lab3
{
    if (!_lab3) {
        _lab3 = [[UILabel alloc]init];
    }
    return _lab3;
}

-(UIButton *)btn
{
    if (!_btn) {
        _btn = [[UIButton alloc]init];
    }
    return _btn;
}

-(UIView *)view1
{
    if (!_view1) {
        _view1 = [[UIView alloc]init];
    }
    return _view1;
}
@end
