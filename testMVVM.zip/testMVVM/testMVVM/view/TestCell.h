//
//  TestCell.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/6.
//

#import <UIKit/UIKit.h>
#import "TestModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface TestCell : UITableViewCell

@property (nonatomic, strong) TestModel *model;
@end

NS_ASSUME_NONNULL_END
