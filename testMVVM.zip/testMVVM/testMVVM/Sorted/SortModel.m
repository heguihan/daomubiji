//
//  SortModel.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/9.
//

#import "SortModel.h"

@implementation SortModel

@end
