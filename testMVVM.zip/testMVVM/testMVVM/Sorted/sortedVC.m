//
//  sortedVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/9.
//

#import "sortedVC.h"
#import "SortModel.h"


@interface sortedVC ()
@property (nonatomic, strong) NSMutableArray *dataArr;
@end

@implementation sortedVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self createUI];
    self.dataArr = [NSMutableArray array];
    [self getData];
}

-(void)getData
{
    for (int i=1; i <5; i++) {
        SortModel *model = [SortModel new];
        model.sort = 5-i;
        if (5-i == 4) {
            model.sort = 888;
        }
        model.name = [NSString stringWithFormat:@"%dxxxxx",5-i];
        [self.dataArr addObject:model];
    }
    
    NSLog(@"arr===%@",self.dataArr);
    
}

-(void)createUI
{
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 100, 30)];
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(click) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor redColor];
}

/*
 var len = arr.length;
 for (var i = 0; i < len - 1; i++) {
     for (var j = 0; j < len - 1 - i; j++) {
         if (arr[j] > arr[j+1]) {        // 相邻元素两两对比
             var temp = arr[j+1];        // 元素交换
             arr[j+1] = arr[j];
             arr[j] = temp;
         }
     }
 }
 return arr;
 */

-(void)click
{
    
    int count = (int)self.dataArr.count;
    for (int i = 0; i<count; i++) {
        for (int j = 0; j<count-1 - i; j++) {
            SortModel *modej = self.dataArr[j];
            SortModel *modelj1 = self.dataArr[j+1];
            if (modej.sort>modelj1.sort) {
                [self.dataArr exchangeObjectAtIndex:j withObjectAtIndex:j+1];
            }
        }
    }
    
    
    

    NSLog(@"self arr==%@",self.dataArr);
    NSLog(@"the end");
    
    
    
}

@end
