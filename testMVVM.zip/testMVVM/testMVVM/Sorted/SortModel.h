//
//  SortModel.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SortModel : NSObject
@property (nonatomic, assign) int sort;
@property (nonatomic, strong) NSString *name;

-(void)modelWithSort:(int)sort name:(NSString *)name;
@end

NS_ASSUME_NONNULL_END
