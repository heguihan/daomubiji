//
//  TestViewModel.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/6.
//

#import "TestViewModel.h"

#import "APIClient.h"
#import "TestModel.h"

@interface TestViewModel()

@property (nonatomic, assign) NSUInteger pageIndex;

@end

@implementation TestViewModel


-(instancetype)init
{
    if (self = [super init]) {
        [self initCancel];
        [self initCommed];
        [self initSubscribe];
        
    }
    return self;
}

-(void)initCancel
{
    _errors = [RACSubject subject];
    
    _cancelCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal *(id input) {
        return [RACSignal empty];
    }];
}

- (void)initCommed
{
    _dataArray = [NSMutableArray arrayWithCapacity:0];
    
    @weakify(self)
    _fetchProductCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal *(id input) {
        @strongify(self)
        self.pageIndex = 0;
        return [[[APIClient sharedClient]
                        fetchProductWithPageIndex:self.pageIndex]
                        takeUntil:self.cancelCommand.executionSignals];
    }];
    
    _fetchMoreProductCommand = [[RACCommand alloc]initWithSignalBlock:^RACSignal *(id input) {
        self.pageIndex = self.pageIndex+1;
        return [[[APIClient sharedClient] fetchProductWithPageIndex:self.pageIndex] takeUntil:self.cancelCommand.executionSignals];
    }];
    
}

- (void)initSubscribe {
    
    @weakify(self);
    [[_fetchProductCommand.executionSignals switchToLatest] subscribeNext:^(id responseObject) {
        @strongify(self);
        
        NSDictionary *responseDict = (NSDictionary *)responseObject;
        
        NSInteger code = [[responseDict objectForKey:@"code"] integerValue];
        
        if (code == 0) {
            
            NSArray *infoArray = [responseDict objectForKey:@"info"];
            NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:0];
            
            [infoArray enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dic,NSUInteger idx,BOOL * _Nonnull stop){
                
                TestModel *model = [TestModel testModelWithDic:dic];
                [tempArray addObject:model];
                
            }];

            /// ⚠️⚠️⚠️注意这里需要通过KVC的方式对数组进行操作
            NSIndexSet *indexSet = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(self.dataArray.count, [tempArray count])];
            [[self mutableArrayValueForKey:@"dataArray"] insertObjects:tempArray atIndexes:indexSet];
            
        } else {
            
            [self.errors sendNext:[NSError new]];
        }

    }];
    
    [[_fetchMoreProductCommand.executionSignals switchToLatest] subscribeNext:^(id responseObject) {
        @strongify(self);
        
        NSDictionary *responseDict = (NSDictionary *)responseObject;
        NSInteger code = [[responseDict objectForKey:@"code"] integerValue];
        
        if (code == 0) {
            
            NSArray *infoArray = [responseDict objectForKey:@"info"];
            NSMutableArray *tempArray = [NSMutableArray arrayWithCapacity:0];

            [infoArray enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dic,NSUInteger idx,BOOL * _Nonnull stop){
                
                TestModel *model = [TestModel testModelWithDic:dic];
                [tempArray addObject:model];

            }];
            
            /// ⚠️⚠️⚠️注意这里需要通过KVC的方式对数组进行操作
            NSIndexSet *indexSet = [NSIndexSet indexSetWithIndexesInRange:NSMakeRange(self.dataArray.count, [tempArray count])];
            [[self mutableArrayValueForKey:@"dataArray"] insertObjects:tempArray atIndexes:indexSet];
            
        } else {
            
            [self.errors sendNext:[NSError new]];
        }
    }];
    
    [[RACSignal merge:@[_fetchProductCommand.errors, self.fetchMoreProductCommand.errors]] subscribe:self.errors];
}


- (void)dealloc {
    [_errors sendCompleted];
}

@end
