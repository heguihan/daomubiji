//
//  TestViewModel.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/6.
//

#import <Foundation/Foundation.h>
#import <ReactiveObjC/ReactiveObjC.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestViewModel : NSObject
@property (nonatomic, strong) NSMutableArray *dataArray;

/**
 *  获取数据Command
 */
@property (nonatomic, strong, readonly) RACCommand *fetchProductCommand;

/**
 *  获取更多数据
 */
@property (nonatomic, strong, readonly) RACCommand *fetchMoreProductCommand;


@property (nonatomic) RACSubject *errors;

/**
 *  取消请求Command
 */
@property (nonatomic, strong, readonly) RACCommand *cancelCommand;

@end

NS_ASSUME_NONNULL_END
