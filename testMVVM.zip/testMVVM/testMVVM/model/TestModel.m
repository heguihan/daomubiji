//
//  TestModel.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/6.
//

#import "TestModel.h"

@implementation TestModel


+ (instancetype)testModelWithDic:(NSDictionary *)dic
{
    TestModel *model = [[TestModel alloc] init];
    model.rtTitle = dic[@"title"];
    model.rtSelect = dic[@"select"];
    
    return model;
}

@end
