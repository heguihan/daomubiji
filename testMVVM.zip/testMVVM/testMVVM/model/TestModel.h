//
//  TestModel.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestModel : NSObject
@property (nonatomic, copy) NSString *rtTitle;
@property (nonatomic, copy) NSString *rtSelect;

+ (instancetype)testModelWithDic:(NSDictionary *)dic;
@end

NS_ASSUME_NONNULL_END
