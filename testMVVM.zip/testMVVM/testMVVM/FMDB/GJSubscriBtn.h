//
//  GJSubscriBtn.h
//  ListenBook
//
//  Created by 感觉 on 2022/5/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GJSubscriBtn : UIButton

@end

NS_ASSUME_NONNULL_END
