//
//  GJSubscriBtn.m
//  ListenBook
//
//  Created by 感觉 on 2022/5/18.
//


#define FIT(value)         value
#define RGBA(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]



#import "GJSubscriBtn.h"
#import <Masonry/Masonry.h>


@interface GJSubscriBtn()
@property (nonatomic, strong) UIImageView *imageV;
@property (nonatomic, strong) UILabel *titleLab;

@end

@implementation GJSubscriBtn

-(instancetype)init
{
    if (self = [super init]) {
        [self configUI];

        [self addobserver];
    }
    return self;
}




-(void)addobserver
{
    [self addObserver:self forKeyPath:@"selected" options:NSKeyValueObservingOptionNew context:@""];
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    id new = [change objectForKey:@"new"];
    BOOL selected = [new boolValue];
    if (selected) {
        [self setSelectedType];
    }else{
        [self setDeselectedType];
    }
}



-(void)configUI
{
    [self addSubview:self.imageV];
    [self addSubview:self.titleLab];
    

    
    
    [self.imageV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.offset(0);
            make.left.offset(FIT(8));
            make.size.mas_equalTo(CGSizeMake(FIT(16), FIT(16)));
    }];
    
    [self.titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.offset(0);
        make.left.mas_equalTo(self.imageV.mas_right).offset(FIT(4));
        make.height.mas_equalTo(16);
        make.width.mas_equalTo(72);
    }];
    [self setDeselectedType];
    
}


-(void)setSelectedType
{
    self.titleLab.text = @"Subscribe";//Subscribed
    self.imageV.image = [UIImage imageNamed:@"icon_add"];//icon_subscribed
    self.backgroundColor = RGBA(255, 240, 239, 1);
}

-(void)setDeselectedType
{
    self.titleLab.text = @"Subscribed";//Subscribed
    self.imageV.image = [UIImage imageNamed:@"icon_subscribed"];//icon_subscribed
    self.backgroundColor = [UIColor whiteColor];
}



-(UIImageView *)imageV
{
    if (!_imageV) {
        _imageV = [[UIImageView alloc]init];
    }
    return _imageV;
}

-(UILabel *)titleLab
{
    if (!_titleLab) {
        _titleLab = [[UILabel alloc]init];
        _titleLab.font = [UIFont systemFontOfSize:13];
        _titleLab.textAlignment = NSTextAlignmentLeft;
        _titleLab.textColor = RGBA(255, 59, 48, 1);
    }
    return _titleLab;
}



@end
