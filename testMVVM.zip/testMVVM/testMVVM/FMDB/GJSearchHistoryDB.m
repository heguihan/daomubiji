//
//  GJSearchHistory.m
//  ListenBook
//
//  Created by 感觉 on 2022/5/19.
//

#import "GJSearchHistoryDB.h"
#import "GJSearchWordModel.h"


@interface GJSearchHistoryDB()
@property (nonatomic, strong) GJDatabase *userDatabase;
@end

@implementation GJSearchHistoryDB

+(instancetype)shareInstance
{
    static GJSearchHistoryDB *searchDB = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        searchDB = [[GJSearchHistoryDB alloc]init];
    });
    return searchDB;
}

-(instancetype)init
{
    if (self = [super init]) {
        [self createDB];
    }
    return self;
}

-(void)createDB
{
    [self.userDatabase creatData:[GJSearchWordModel class] primary:@"keyword" isAutoincrement:NO];
}

//增加单条
-(void)addDataWithModel:(NSString *)keyword
{
    
    GJSearchWordModel *model = [[GJSearchWordModel alloc]init];
    model.keyword = keyword;
    model.timestr = [GJTools getIntCurrentTime];
    
    BOOL result = [self.userDatabase addDataWithModel:model];
    if (result) {
        int total = [self.userDatabase searchCountPrimaryKey:@"keyword"];
        if (total>15) {
            //进行删除
            [self.userDatabase deleteMoreThan:15];
        }
    }else{
        //自信点， 插入失败就是主键相同， 所以直接修改
        [self updatetimekeywordvalue:keyword];
    }
}
//删除单条
-(void)deleteSignleWithKeyword:(NSString *)value
{
    [self.userDatabase deleteDatakey:@"keyword" value:value];
}
//删除所有
-(void)deleteAll
{
    [self.userDatabase deleteAllData];
}
//删除超过15条的数据
-(void)deleteMorethan15
{
    [self.userDatabase deleteMoreThan:15];
}

//改
-(void)updatetimekeywordvalue:(NSString *)value
{
    NSInteger time = [GJTools getIntCurrentTime];
    [self.userDatabase updateSiglevalueprimaryKey:@"keyword" primaryValue:value updateKey:@"timestr" updateValue:[NSString stringWithFormat:@"%ld",time]];
}
//查
-(NSArray *)queryAll
{
    NSMutableArray *arr = [self.userDatabase queryAllData:[GJSearchWordModel class]];
    NSMutableArray *mutabArr = [NSMutableArray array];
    if (arr.count<1) {
        return [mutabArr copy];
    }
    for (NSDictionary *dict in arr) {
        NSString *keyWord = [dict objectForKey:@"keyword"];
        [mutabArr addObject:keyWord];
    }
    return [mutabArr copy];
}



#pragma mark -- getter

-(GJDatabase *)userDatabase
{
    if (!_userDatabase) {
        _userDatabase = [[GJDatabase alloc]init];
        _userDatabase.tableName = @"gjwavee_test1_history_search";
    }
    return _userDatabase;
}

@end
