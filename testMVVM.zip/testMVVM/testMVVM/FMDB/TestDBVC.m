//
//  TestDBVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/18.
//

#define RGBA(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

#import "TestDBVC.h"
#import "GJDatabase.h"
#import "TestDataModel.h"
#import "DBmodel.h"
#import "GJSubscriBtn.h"
#import <Masonry/Masonry.h>

@interface TestDBVC ()
@property (nonatomic, strong) UITextField *myTF;
@property (nonatomic, strong) GJDatabase *userDatabase;
@property (nonatomic, strong) UIButton * subBtn;
@end

@implementation TestDBVC

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self createUI];
    [self createButton];
}

-(void)createButton
{
    GJSubscriBtn *subbtn = [[GJSubscriBtn alloc]init];
    [self.view addSubview:subbtn];
    [subbtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.offset(100);
            make.size.mas_equalTo(CGSizeMake(102, 36));
    }];
//    subbtn.frame = CGRectMake(100, 100, 103, 32);
    
    [subbtn layoutIfNeeded];
    CGFloat height = subbtn.frame.size.height;
    subbtn.layer.cornerRadius = height/2.0;
    subbtn.layer.masksToBounds = YES;
    
    
    [subbtn addTarget:self action:@selector(clickSubBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    
}

-(void)clickSubBtn:(UIButton *)sender
{
    sender.selected = !sender.selected;
//    self.subBtn.backgroundColor = self.subBtn.selected ? [UIColor grayColor]  : RGBA(255, 240, 239, 1);
}


-(void)createUI
{
    NSArray *arr = @[@"创建",@"增",@"删",@"改",@"查",@"其他"];
    for (int i=0; i<6; i++) {
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 50+50*i, 100, 30)];
        [btn setTitle:arr[i] forState:UIControlStateNormal];
        btn.backgroundColor = [UIColor orangeColor];
        [self.view addSubview:btn];
        btn.tag = 100+i;
        [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    self.myTF = [[UITextField alloc]initWithFrame:CGRectMake(100, 350, 100, 30)];
    [self.view addSubview:self.myTF];
    self.myTF.backgroundColor = [UIColor grayColor];
}

-(void)creatData
{
    [self.userDatabase creatData:[DBmodel class] unique:@"book_id"];
}


static int _book_id =12344321;
-(void)addData
{
    _book_id += 1;
    DBmodel *model = [[DBmodel alloc]init];
//    model.name = @"aaaa";
    model.time = 11;
    model.book_id = [NSString stringWithFormat:@"%d",_book_id];
    model.pic = @"https://www.baudi.com/1233dsdd";
//    model.age = 10;
    model.isTaged = NO;
    model.timestr = [self getCurrentTimeStr];
    [self.userDatabase addDataWithModel:model];
    
    
}

-(void)deleteData
{
    [self.userDatabase deleteMoreThan:10];
}

-(void)changeData
{
    [self.userDatabase updateSiglevalueprimaryKey:@"book_id" primaryValue:@"12344326" updateKey:@"age" updateValue:@"123"];

}

-(void)searchData
{
    NSMutableArray *arr = [self.userDatabase queryAllData:[DBmodel class]];
    NSLog(@"arr==%@",arr);
}

-(void)other
{
    int totalCount = [self.userDatabase searchCountPrimaryKey:@"book_id"];
}





-(void)click:(UIButton *)sender
{
    switch (sender.tag) {
        case 100:
            [self creatData];
            break;
        case 101:
            [self addData];
            break;
        case 102:
            [self deleteData];
            break;
        case 103:
            [self changeData];
            break;
        case 104:
            [self searchData];
            break;
        case 105:
            [self other];
            break;
            
        default:
            break;
    }
}


-(GJDatabase *)userDatabase
{
    if (!_userDatabase) {
        _userDatabase = [[GJDatabase alloc]init];
        _userDatabase.tableName = @"test_bookp7";
    }
    return _userDatabase;
}

//
-(NSInteger *)getCurrentTimeStr
{
    double timed = [[NSDate date] timeIntervalSince1970];
    NSInteger timeI = (NSInteger)timed;
//    NSString *dateStr = [NSString stringWithFormat:@"%ld", timeI];
    return timeI;
}

@end
