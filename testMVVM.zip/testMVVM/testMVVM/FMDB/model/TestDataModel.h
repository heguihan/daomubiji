//
//  TestDataModel.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestDataModel : NSObject
@property (nonatomic, strong) NSString *secondTypeId;
@property (nonatomic, strong) NSString *coverUrl;
@property (nonatomic, strong) NSString *alias;
@property (nonatomic, assign) int chapterTotal;
@property (nonatomic, strong) NSString *createdAt;
@property (nonatomic, assign) int createdBy;
@property (nonatomic, strong) NSString *createdByName;
@property (nonatomic, assign) int currMonthVisits;
@property (nonatomic, assign) int duration;
@property (nonatomic, strong) NSString *firstTypeId;
@property (nonatomic, strong) NSString *firstTypeName;
@property (nonatomic, strong) NSString *i18nLang;
@property (nonatomic, strong) NSString *book_id;
@property (nonatomic, strong) NSString *introduction;
@property (nonatomic, assign) BOOL isRecommend;
@property (nonatomic, strong) NSString *keywords;
@property (nonatomic, assign) int listeners;
@property (nonatomic, strong) NSString *modifiedAt;
@property (nonatomic, strong) NSString *modifiedBy;
@property (nonatomic, strong) NSString *modifiedByName;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *remark;
@property (nonatomic, strong) NSString *secondTypeName;
@property (nonatomic, assign) int sort;
@property (nonatomic, assign) int state;
@property (nonatomic, assign) int subscribers;
@property (nonatomic, assign) int type;
@property (nonatomic, assign) int visitsTotal;
@end

NS_ASSUME_NONNULL_END
