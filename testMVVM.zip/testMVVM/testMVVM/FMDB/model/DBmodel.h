//
//  DBmodel.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DBmodel : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *book_id;
@property (nonatomic, strong) NSString *pic;
@property (nonatomic, assign) int age;
@property (nonatomic, assign) int time;
@property (nonatomic, assign) BOOL isTaged;
@property (nonatomic, assign) NSInteger timestr;




@end

NS_ASSUME_NONNULL_END
