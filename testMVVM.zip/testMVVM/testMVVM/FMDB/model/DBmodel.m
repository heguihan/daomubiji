//
//  DBmodel.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/18.
//

#import "DBmodel.h"

@implementation DBmodel

@end
