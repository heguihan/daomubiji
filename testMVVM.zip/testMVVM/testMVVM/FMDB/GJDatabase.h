//
//  GJDatabase.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/10.
//

#import <Foundation/Foundation.h>



NS_ASSUME_NONNULL_BEGIN

@interface GJDatabase : NSObject
@property (nonatomic, strong) NSString *tableName;




-(BOOL)creatData:(Class)class primary:(NSString *)primaryKey isAutoincrement:(BOOL)isIncrement;
-(BOOL)addDataWithModel:(id)model;
//删除单条数据
-(BOOL)deleteDatakey:(NSString *)key value:(NSString *)value;
#pragma mark - 删除数据:全部删除
- (BOOL)deleteAllData;
#pragma mark - 更新数据:单条更新
-(BOOL)changeDatak:(id)model key:(NSString *)key value:(NSString *)value;
#pragma mark - 更新数据:单值更新
- (BOOL)updateSiglevalueprimaryKey:(NSString *)primaryKey primaryValue:(NSString *)primaryValue updateKey:(NSString *)updateKey updateValue:(NSString *)updateValue;
#pragma mark - 查询数据:单条数据
- (NSMutableArray *)querySiglekey:(NSString *)key value:(NSString *)value;
#pragma mark - 查询数据:全部数据
- (NSMutableArray *)queryAllData:(Class)class;
//超过50条 删除
-(void)deleteMoreThan:(int)value;
//查询数量
-(int)searchCountPrimaryKey:(NSString *)primaryKey;
-(void)other;

@end

NS_ASSUME_NONNULL_END
