//
//  GJSearchHistory.h
//  ListenBook
//
//  Created by 感觉 on 2022/5/19.
//

#import <Foundation/Foundation.h>
#import "GJDatabase.h"


NS_ASSUME_NONNULL_BEGIN

@interface GJSearchHistoryDB : NSObject

+(instancetype)shareInstance;

//增加单条
-(void)addDataWithModel:(NSString *)keyword;
//删除单条
-(void)deleteSignleWithKeyword:(NSString *)value;
//删除所有
-(void)deleteAll;
//改
-(void)updatetimekeywordvalue:(NSString *)value;
//查
-(NSArray *)queryAll;
@end








NS_ASSUME_NONNULL_END
