//
//  GJDatabase.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/10.
//

#import "GJDatabase.h"
#import <FMDB.h>
#import <objc/runtime.h>



@interface GJDatabase()

@property (nonatomic, strong) FMDatabase *db;

@end

@implementation GJDatabase



-(BOOL)creatData:(Class)class primary:(NSString *)primaryKey isAutoincrement:(BOOL)isIncrement
{
    NSDictionary *typeDict  = @{@"Ti":@"integer",@"TB":@"integer",@"T@\"NSString\"":@"text"};
    
    NSMutableString * sql = [NSMutableString stringWithFormat:@"create table if not exists '%@' (", self.tableName];
//    [sql appendString:@"'%@' test primary key ",uniqueKey];
    if (isIncrement) {
        [sql appendFormat:@"'%@' integer primary key autoincrement",primaryKey];
    }else{
        [sql appendFormat:@"'%@' test primary key ",primaryKey];
    }
    
    unsigned int count = 0;
    objc_property_t *properties = class_copyPropertyList(class, &count);
    for (int i = 0; i<count; i++) {
        objc_property_t propertyx = properties[i];
        NSString *propertyName = [NSString stringWithUTF8String:property_getName(propertyx)];
        const char *propertyChar = property_getAttributes(propertyx);
        NSString *propertyNamex = [NSString stringWithUTF8String:propertyChar];
        NSString *typeKey = [propertyNamex componentsSeparatedByString:@","][0];
        NSString *typeStr = [typeDict objectForKey:typeKey];
        if (!typeStr || typeStr.length<1) {
            typeStr = @"text";
        }
        if ([propertyName isEqualToString:primaryKey]) {
            continue;
        }
        [sql appendFormat:@",'%@' %@", propertyName,typeStr];
    }
    [sql appendString:@")"];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];

    NSString *infraredDataBasePath = [documentDirectory stringByAppendingPathComponent:@"gjwavee.db"];
    NSLog(@"path==%@",infraredDataBasePath);
    FMDatabase *db = [FMDatabase databaseWithPath:infraredDataBasePath];
    self.db = db;
    if ([db open]) {
        NSLog(@"打开成功");
        if ([db executeUpdate:sql]) {
            NSLog(@"创建表成功！");
            return YES;
        }else {
            return NO;
        }
    }else{
        NSLog(@"open error");
        return NO;
    }
}

-(BOOL)addDataWithModel:(id)model
{
    unsigned int count = 0;
    NSMutableString * keys = [NSMutableString stringWithFormat:@"("];
    NSMutableString * values = [NSMutableString stringWithFormat:@"("];
//    NSMutableArray * mArr = [NSMutableArray arrayWithCapacity:0];
    Ivar * ivars = class_copyIvarList([model class], &count);
    for (int i = 0; i<count; i++) {
        Ivar ivar = ivars[i];
        const char * name = ivar_getName(ivar);
        NSString * key = [NSString stringWithUTF8String:name];
        [keys appendFormat:@"%@, ", [key substringFromIndex:1]];
        [values appendFormat:@"'%@', ",[model valueForKey:key]];
//        [mArr addObject:[model valueForKey:key]];
    }
    [keys deleteCharactersInRange:NSMakeRange(keys.length - 2, 2)];
    [keys appendFormat:@")"];
    
    [values deleteCharactersInRange:NSMakeRange(values.length - 2, 2)];
    [values appendFormat:@")"];
    free(ivars);
    
    NSString * sql = [NSString stringWithFormat:@"insert into '%@' %@ values %@", self.tableName, keys, values];
//    sql = @"insert into 'test_book' (age, time, name, book_id, pic) values ('10', '11', 'aaaa', '1234561', 'https://www.baudi.com/1233dsdd')";
    NSLog(@"sql==%@",sql);
    if ([self.db executeUpdate:sql]) {
        NSLog(@"插入数据成功！");
        return YES;
        
    }else NSLog(@"插入数据失败");
    return NO;
}

-(BOOL)deleteDatakey:(NSString *)key value:(NSString *)value
{
    NSString *sql = [NSString stringWithFormat:@"delete from '%@' where %@ = '%@'",self.tableName,key,value];
    NSLog(@"sql==%@",sql);
    if ([self.db executeUpdate:sql]) {
        NSLog(@"删除数据成功！");
        return YES;
    }else NSLog(@"删除数据失败！");
    return NO;
}

#pragma mark - 删除数据:全部删除
- (BOOL)deleteAllData{
    NSString * sql = [NSString stringWithFormat:@"delete from '%@'", self.tableName];
    BOOL result = [self.db executeUpdate:sql];
    if (result) {
        NSLog(@"%s - 表: 删除全部数据成功", __func__);
    } else {
        NSLog(@"%s - 表: 删除全部数据失败", __func__);
    }
    return result;
}

#pragma mark - 更新数据:单条更新
-(BOOL)changeDatak:(id)model key:(NSString *)key value:(NSString *)value
{
    NSMutableString * sql = [NSMutableString stringWithFormat:@"update '%@' set ", self.tableName];
    unsigned int count = 0;
    Ivar * ivars = class_copyIvarList([model class], &count);
    for (int i = 0; i<count; i++) {
        Ivar ivar = ivars[i];
        const char * name = ivar_getName(ivar);
        NSString * key = [NSString stringWithUTF8String:name];
        [sql appendFormat:@"%@ = '%@', ", [key substringFromIndex:1], [model valueForKey:key]];
    }
    [sql deleteCharactersInRange:NSMakeRange(sql.length - 2, 2)];
    [sql appendFormat:@" where %@ = '%@'", key, value];
    BOOL result = [self.db executeUpdate:sql];
    if (result) {
        NSLog(@"%s - 表: 更新数据成功", __func__);
    } else {
        NSLog(@"%s - 表: 更新数据失败", __func__);
    }
    return result;
}

#pragma mark - 更新数据:单值更新
- (BOOL)updateSiglevalueprimaryKey:(NSString *)primaryKey primaryValue:(NSString *)primaryValue updateKey:(NSString *)updateKey updateValue:(NSString *)updateValue  {
    
    NSMutableString * sql = [NSMutableString stringWithFormat:@"update '%@' set ", self.tableName];
    [sql appendFormat:@"%@ = '%@'", updateKey, updateValue];
    [sql appendFormat:@" where %@ = '%@'", primaryKey, primaryValue];
    BOOL result = [self.db executeUpdate:sql];
    if (result) {
        NSLog(@"%s - 表: 更新数据成功", __func__);
    } else {
        NSLog(@"%s - 表: 更新数据失败", __func__);
    }
    return result;
}


#pragma mark - 查询数据:单条数据
- (NSMutableArray *)querySiglekey:(NSString *)key value:(NSString *)value {
    // 查询数据
    NSString * sql = [NSString stringWithFormat:@"select * from '%@' where %@ = '%@'", self.tableName, key, value];
    FMResultSet * resultSet = [self.db executeQuery:sql];
    id model = nil;
    NSMutableArray * mArr = [NSMutableArray arrayWithCapacity:0];
    while ([resultSet next]) {
        model = [self.class new];
        
        unsigned int count = 0;
        Ivar * ivars = class_copyIvarList([model class], &count);
        for (int i = 0; i<count; i++) {
            Ivar ivar = ivars[i];
            const char * name = ivar_getName(ivar);
            NSString * key = [NSString stringWithUTF8String:name];
            [model setValue:[resultSet stringForColumn:[key substringFromIndex:1]] forKey:key];
        }
        [mArr addObject:model];
    }
    return mArr;
}

#pragma mark - 查询数据:全部数据
- (NSMutableArray *)queryAllData:(Class)class {
    NSString * sql = [NSString stringWithFormat:@"select * from '%@'", self.tableName];
    FMResultSet * resultSet = [self.db executeQuery:sql];
    id model = nil;
    
    NSMutableArray * mArr = [NSMutableArray arrayWithCapacity:0];
    while ([resultSet next]) {
        model = [class new];
        NSMutableDictionary *mutabDict = [NSMutableDictionary dictionary];
        unsigned int count = 0;
//        Ivar * ivars = class_copyIvarList([model class], &count);
        objc_property_t *properties = class_copyPropertyList(class, &count);
        for (int i = 0; i<count; i++) {
//            Ivar ivar = ivars[i];
//            const char * name = ivar_getName(ivar);
//            NSString * key = [NSString stringWithUTF8String:name];
            objc_property_t propertyx = properties[i];
            NSString *key = [NSString stringWithUTF8String:property_getName(propertyx)];
            [mutabDict setValue:[resultSet stringForColumn:key] forKey:key];
        }
        [mArr addObject:mutabDict];
    }
    return mArr;
}

//超过50条 删除
-(void)deleteMoreThan:(int)value
{
    NSString *sql =[NSString stringWithFormat:@"DELETE FROM %@ AS t WHERE t.timestr <= (SELECT t1.timestr FROM %@  AS t1 ORDER BY t1.timestr DESC LIMIT %d,1)", self.tableName,self.tableName,value];
    BOOL result = [self.db executeUpdate:sql];
    if (result) {
        NSLog(@"删除成功");
    }else{
        NSLog(@"删除失败");
    }
}

//查询数量
-(int)searchCountPrimaryKey:(NSString *)primaryKey
{
    NSString *sql = [NSString stringWithFormat:@"SELECT COUNT(%@) FROM %@",primaryKey,self.tableName];
    FMResultSet *s = [self.db executeQuery:sql];
    if ([s next]) {
    int totalCount = [s intForColumnIndex:0];
        return totalCount;
    }
    return 0;
}
-(void)other
{
    if (![self.db columnExists:@"newcc" inTableWithName:@"names"]){
         NSString *alertStr = [NSString stringWithFormat:@"ALTER TABLE %@ ADD %@ INTEGER",@"names",@"newcc"];
        BOOL worked = [self.db executeUpdate:alertStr];
        if(worked){
        NSLog(@"插入成功");
        }else{
            NSLog(@"插入失败");
        }
    }
}



@end
