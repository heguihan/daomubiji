//
//  FMDBVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/10.
//

#import "FMDBVC.h"
#import <FMDB.h>


@interface FMDBVC ()
@property (nonatomic, strong) FMDatabase *db;
@property (nonatomic, strong) UITextField *myTF;

@end

@implementation FMDBVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createUI];
//    [self creatData];
}

-(void)createUI
{
    NSArray *arr = @[@"创建",@"增",@"删",@"改",@"查",@"其他"];
    for (int i=0; i<6; i++) {
        UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 50+50*i, 100, 30)];
        [btn setTitle:arr[i] forState:UIControlStateNormal];
        btn.backgroundColor = [UIColor orangeColor];
        [self.view addSubview:btn];
        btn.tag = 100+i;
        [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    self.myTF = [[UITextField alloc]initWithFrame:CGRectMake(100, 350, 100, 30)];
    [self.view addSubview:self.myTF];
    self.myTF.backgroundColor = [UIColor grayColor];

}

-(void)creatData
{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];

    NSString *infraredDataBasePath = [documentDirectory stringByAppendingPathComponent:@"test1db.db"];
    NSLog(@"path==%@",infraredDataBasePath);
    FMDatabase *db = [FMDatabase databaseWithPath:infraredDataBasePath];
    self.db = db;
    if ([db open]) {
        NSLog(@"打开成功");
        if ([db executeUpdate:@"create table if not exists names (name text,age INTEGER)"]) {
            NSLog(@"创建表成功！");
        }else {
            NSLog(@"创建表失败");
        }
    }else{
        NSLog(@"open error");
    }
}

-(void)addData
{
    NSString *sql = [NSString stringWithFormat:@"insert into names (name,age) values ('%@','%d')",self.myTF.text,11];
    NSLog(@"sql==%@",sql);
    if ([self.db executeUpdate:sql]) {
        NSLog(@"插入数据成功！");
    }else NSLog(@"插入数据失败");
}

-(void)deleteData
{
    NSString *sql = [NSString stringWithFormat:@"delete from names where name='%@'",self.myTF.text];
    NSLog(@"sql==%@",sql);
    if ([self.db executeUpdate:sql]) {
        NSLog(@"删除数据成功！");
    }else NSLog(@"删除数据失败！");
}

-(void)changeData
{
    NSString *sql = [NSString stringWithFormat:@"update names set name='%@' where name = '%@'",self.myTF.text,@"Aaasss"];
    NSLog(@"sql==%@",sql);
    if ([self.db executeUpdate:sql]) {
        NSLog(@"修改数据成功！");
    }else NSLog(@"修改数据失败！");

}

-(void)searchData
{
    FMResultSet *result = [self.db executeQuery:@"select * from names"];
    while ([result next]) {

        NSString *name = [result stringForColumn:@"name"];
        //如果是年龄需要用intforcolumn
        int age = [result intForColumn:@"age"];

        NSLog(@"%@,age=%d",name,age);
    }
}

-(void)other
{
    if (![self.db columnExists:@"newcc" inTableWithName:@"names"]){
         NSString *alertStr = [NSString stringWithFormat:@"ALTER TABLE %@ ADD %@ INTEGER",@"names",@"newcc"];
        BOOL worked = [self.db executeUpdate:alertStr];
        if(worked){
        NSLog(@"插入成功");
        }else{
            NSLog(@"插入失败");
        }
    }
}

-(void)click:(UIButton *)sender
{
    switch (sender.tag) {
        case 100:
            [self creatData];
            break;
        case 101:
            [self addData];
            break;
        case 102:
            [self deleteData];
            break;
        case 103:
            [self changeData];
            break;
        case 104:
            [self searchData];
            break;
        case 105:
            [self other];
            break;
            
        default:
            break;
    }
}




@end
