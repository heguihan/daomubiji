//
//  TabVC.m
//  testMVVM
//
//  Created by 感觉 on 2022/5/19.
//

#import "TabVC.h"

@interface TabVC ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableview;

@end

@implementation TabVC

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"tabVC");
    [self createUI];
}

-(void)createUI
{
    [self.view addSubview:self.tableview];
    [self.tableview registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    self.tableview.tableHeaderView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 1, 0.1)];
    self.tableview.sectionHeaderTopPadding = 0;
//    if (@available(iOS 11.0, *)) {
//         self.tableview.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
//    } else {
//         self.automaticallyAdjustsScrollViewInsets = NO;
//    }
    
    self.tableview.estimatedRowHeight = 0;
    self.tableview.estimatedSectionHeaderHeight = 0;
    self.tableview.estimatedSectionFooterHeight = 0;
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 1) {
        return 80;
    }
    return 10;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"index==%ld, %ld",indexPath.row,indexPath.section);
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 20;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.1;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 390, 20)];
    view.backgroundColor = [UIColor blueColor];
    return view;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row];
    cell.backgroundColor = [UIColor orangeColor];
    return cell;
}


-(UITableView *)tableview
{
    if (!_tableview) {
        CGRect frame = CGRectMake(0, 100, 390, 790);
        _tableview = [[UITableView alloc]initWithFrame:frame style:1];
        _tableview.backgroundColor = [UIColor redColor];
        _tableview.delegate = self;
        _tableview.dataSource = self;
    }
    return _tableview;
}

@end
