//
//  TabVC.h
//  testMVVM
//
//  Created by 感觉 on 2022/5/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TabVC : UIViewController

@end

NS_ASSUME_NONNULL_END
